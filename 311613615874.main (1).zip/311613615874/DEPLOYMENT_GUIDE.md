# Cdiscount USA 项目部署指南

这是一个详细的、面向初学者的部署指南，即使你没有任何网站搭建经验，也能按照这个指南一步步完成部署！

## 前提条件

在开始之前，你需要准备以下工具：
1. 一台可以上网的电脑
2. 一个浏览器（推荐Chrome或Firefox）
3. 一个GitHub账号（免费注册）

## 部署方式选择

我为你准备了几种部署方式，从最简单到稍微复杂的，你可以根据自己的情况选择：

### 方式一：使用 Vercel 一键部署（推荐，最简单）

Vercel 是一个免费的网站托管平台，可以一键部署你的React项目，完全不需要懂代码！

#### 步骤 1：注册 GitHub 账号
如果你还没有GitHub账号，请先[点击这里注册](https://github.com/signup)，这是免费的。

#### 步骤 2：复制项目代码到你的 GitHub
1. 访问 [GitHub](https://github.com) 并登录
2. 点击右上角的 "+" 按钮，选择 "New repository"
3. 仓库名称可以随便取，比如 "cdiscount-usa"
4. 选择 "Public"（公共）
5. 点击 "Create repository" 创建仓库
6. 现在你有了一个空仓库，回到你的电脑，打开命令提示符（Windows）或终端（Mac/Linux）
7. 复制下面的命令，粘贴到命令提示符/终端中，并按回车执行：
   ```
   git clone https://github.com/your-username/cdiscount-usa.git
   cd cdiscount-usa
   git pull https://github.com/original-owner/original-repo.git main
   git push origin main
   ```
   注意：把 "your-username" 改成你的GitHub用户名，把 "original-owner/original-repo" 改成原始代码仓库地址

#### 步骤 3：使用 Vercel 一键部署
1. 访问 [Vercel官网](https://vercel.com)
2. 点击右上角的 "Sign Up" 注册账号（可以直接用GitHub账号登录）
3. 登录后，点击 "New Project"
4. 选择你的 "cdiscount-usa" 仓库
5. 点击 "Import" 按钮
6. 保持默认设置，点击 "Deploy" 按钮
7. 等待几分钟，Vercel会自动构建并部署你的网站
8. 部署完成后，你会得到一个类似 `https://cdiscount-usa.vercel.app` 的网址，这就是你的网站地址！

### 方式二：使用 Netlify 一键部署

Netlify 和 Vercel 类似，也是一个免费的网站托管平台。

#### 步骤 1：注册 GitHub 账号（同上）

#### 步骤 2：复制项目代码到你的 GitHub（同上）

#### 步骤 3：使用 Netlify 一键部署
1. 访问 [Netlify官网](https://www.netlify.com)
2. 点击右上角的 "Sign Up" 注册账号（可以直接用GitHub账号登录）
3. 登录后，点击 "New site from Git"
4. 选择 "GitHub"，然后选择你的 "cdiscount-usa" 仓库
5. 保持默认设置，点击 "Deploy site" 按钮
6. 等待几分钟，Netlify会自动构建并部署你的网站
7. 部署完成后，你会得到一个类似 `https://your-site-name.netlify.app` 的网址，这就是你的网站地址！

### 方式三：使用 GitHub Pages 部署

GitHub Pages 是 GitHub 提供的免费静态网站托管服务。

#### 步骤 1：修改项目配置
1. 打开项目中的 `package.json` 文件
2. 在 `scripts` 部分添加一行：
   ```json
   "deploy": "npm run build && npx gh-pages -d dist"
   ```
3. 在文件末尾添加一行：
   ```json
   "homepage": "https://your-username.github.io/cdiscount-usa"
   ```
   注意：把 "your-username" 改成你的GitHub用户名

#### 步骤 2：安装依赖并部署
1. 打开命令提示符（Windows）或终端（Mac/Linux）
2. 导航到你的项目文件夹
3. 运行以下命令：
   ```
   npm install -g gh-pages
   npm install
   npm run deploy
   ```
4. 等待部署完成，你的网站就会发布在 `https://your-username.github.io/cdiscount-usa`

## 高级部署选项（使用自己的服务器）

如果你有自己的服务器，或者想要更灵活的部署方式，可以按照以下步骤进行：

### 步骤 1：准备服务器
1. 购买一个云服务器（推荐阿里云、腾讯云、AWS等）
2. 安装 Node.js（推荐版本 16.x 或更高）
3. 安装 Nginx（一个网页服务器软件）

### 步骤 2：构建项目
1. 在本地电脑上，打开命令提示符（Windows）或终端（Mac/Linux）
2. 导航到你的项目文件夹
3. 运行以下命令构建项目：
   ```
   npm install
   npm run build
   ```
4. 构建完成后，项目根目录会生成一个 `dist` 文件夹，里面包含了所有需要部署的文件

### 步骤 3：部署到服务器
1. 使用 FTP 工具（如 FileZilla）将 `dist` 文件夹中的所有文件上传到你的服务器
2. 配置 Nginx 以提供这些文件
3. 你可以参考网上的 Nginx 配置教程，这部分稍微复杂一点

## 绑定自定义域名

如果你想使用自己的域名（例如 `www.your-site.com`），可以按照以下步骤操作：

### 步骤 1：购买域名
1. 访问域名注册商（如阿里云、腾讯云、GoDaddy等）
2. 搜索并购买你喜欢的域名

### 步骤 2：配置域名解析
1. 在域名注册商的管理后台，找到 "域名解析" 或 "DNS 设置"
2. 添加一条 A 记录，将你的域名指向你的服务器IP地址（如果使用Vercel或Netlify，则按照它们的文档进行配置）

### 步骤 3：在托管平台配置自定义域名
1. 如果你使用 Vercel 或 Netlify，登录到它们的后台
2. 找到你的项目，进入设置页面
3. 找到 "自定义域名" 选项，按照提示添加你的域名

## 常见问题解决

1. **部署后网站显示空白？**
   - 检查是否正确构建了项目
   - 检查浏览器控制台是否有错误信息
   - 确保所有文件都已正确上传

2. **页面可以访问，但样式不对？**
   - 检查 CSS 文件路径是否正确
   - 尝试重新构建并部署项目

3. **自定义域名无法访问？**
   - 检查域名解析是否正确配置
   - DNS 记录可能需要 24-48 小时才能全球生效

如果你在部署过程中遇到任何问题，可以随时联系我获取帮助！